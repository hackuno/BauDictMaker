BauDictMaker
Let my "bau" eat some input and POP-OUT to you all the !-pOSSIble%cOmBInAtions_!

N.B: This software is under development but it will be completed very soon! In a few days (let me understand how) it will be avaiable on linux platform as apt-get install **** (at least it is my wish) please be patient :)

N.N.B. the "single line" mode is not ready yet so you will not able to
pass the output to other software / file

http://www.hackubau.it/HackuBauDictionary
